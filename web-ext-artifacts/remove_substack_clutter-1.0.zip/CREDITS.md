Icon Credit

- "Broom" by FortAwesome, https://www.svgrepo.com/svg/351806/broom
- License: CC Attribution License — https://www.svgrepo.com/page/licensing/#CC%20Attribution
- Modifications: Resized and recolored to #ff5900
